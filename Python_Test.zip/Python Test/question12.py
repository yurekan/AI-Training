import threading

# Function to calculate the sum of even numbers
def even_sum(num):
    result = 0
    for i in num:
        if i%2 == 0:
            result += i
    print(f'Sum of even numbers is {result}')

# Function to calculate the sum of odd numbers
def odd_sum(num):
    result = 0
    for i in num:
        if i%2 != 0:
            result += i
    print(f'Sum of odd numbers is {result}')

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Create threads for even and odd sum calculations
thread1 = threading.Thread(target=even_sum, args=(numbers, ))
thread2 = threading.Thread(target=odd_sum, args=(numbers, ))

# Start the threads
thread1.start()
thread2.start()

thread1.join()
thread2.join()
