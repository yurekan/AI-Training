import time
import math

# defining decorator to take any function and execute it.
def log_execution(func):


    # Takes argument to execute the function.
    def calculate_time(*args):

        # Starting the timer before the function execution
        begin = time.time()
        # Executing the function
        func(*args)
        # Starting the timer after the function execution
        end = time.time()

        print(f"Total time taken for {func.__name__} function to execute is {end - begin}")

    return calculate_time

@log_execution
def square(num):
    print(f"Square of {num} is {math.pow(num, 2)}")

square(6)