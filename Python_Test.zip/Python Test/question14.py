def calculate_average(*args, **kwargs):

    # Combine positional and keyword arguments into a single list
    numbers = list(args) + list(kwargs.values())
    
    # Check if there are any numbers to calculate the average
    if not numbers:
        raise ValueError("At least one number must be provided.")
    
    # Calculate the average
    average = sum(numbers) / len(numbers)
    return average

positional_average = calculate_average(10, 20, 30)  # Using positional arguments
keyword_average = calculate_average(a=10, b=20, c=30)  # Using keyword arguments
mixed_average = calculate_average(10, 20, a=30, b=40)  # Mixed arguments

print(positional_average)  
print(keyword_average)     
print(mixed_average)       