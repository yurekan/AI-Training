# Base class
class Animal:
    def make_sound(self):
        return "Some generic sound"

    def move(self):
        return "Moves in some way"


# Derived class Dog
class Dog(Animal):
    def make_sound(self):
        return "Bark!"

    def move(self):
        return "Runs on four legs."


# Derived class Cat
class Cat(Animal):
    def make_sound(self):
        return "Meow!"

    def move(self):
        return "Sneaks gracefully."


if __name__ == "__main__":

    # Create instances of Dog and Cat
    obj1 = Dog()
    obj2 = Cat()

    # Call their methods
    print("Dog:")
    print("Sound:", obj1.make_sound())
    print("Movement:", obj1.move())

    print("\nCat:")
    print("Sound:", obj2.make_sound())
    print("Movement:", obj2.move())
