def calculate_sum(numbers):
    total = 0
    for number in numbers:
        total += number
    return total

# Deliberate error: passing a string instead of a list of numbers
result = calculate_sum("12345")
print("Sum:", result)

# Steps to run the program with pdb:
# 1. Save this script as `question20.py`.
# 2. Open a terminal or command prompt.
# 3. Navigate to the directory where `question20.py` is saved.
# 4. Run the script using pdb:
#    python -m pdb question20.py
# 5. Use the `n` command to step through the code.
# 6. When you reach the error, note the error message.
# 7. Fix the error by changing the input to a list of numbers:
#    result = calculate_sum([1, 2, 3, 4, 5])
# 8. Save the changes and rerun the script to see the correct output.
