class EvenNumberIterator:
    def __init__(self, lower_bound, upper_bound):
        # Initialize the iterator with lower and upper bounds
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound

    def __iter__(self):
        # Set the starting point for the iteration
        self.x = self.lower_bound
        return self
    
    def __next__(self):
        # Check if the current number is even; if not, move to the next even number
        if self.x % 2 == 0:
            x = self.x  # Current number is even
        else:
            x = self.x + 1  # Move to the next even number

        # If the even number exceeds the upper bound, stop the iteration
        if x > self.upper_bound:
            raise StopIteration
        
        # Prepare the next even number for the next call
        self.x = x + 2  # Move to the next even number (current + 2)

        return x  # Return the current even number

for i in EvenNumberIterator(11, 19):
    print(i)  
