import re

def extract_emails(input_string):

    # Regex pattern for matching email addresses
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    # Use findall to get all email addresses
    return re.findall(email_pattern, input_string)


input_string = input("Enter a string containing email addresses: ")
print("Extracted email addresses:", extract_emails(input_string))
