
# generator function to yield prime numbers
def prime_numbers(limit):
    
    # funciton to check if a number is prime or not
    def is_prime(n):
        if n <= 1:
            return False
    
        for i in range(2, int(n*0.5) + 1):
            if n % i == 0:
                return False
        
        return True
    
    for num in range(2, limit + 1):
        if(is_prime(num)):
            yield num

num = int(input("Enter the limit of the function: "))

# create a generator object
numbers = prime_numbers(num)
print(f"Prime numbers in limit {num} are : ")
# Iterate over the generator object and print each value
for i in numbers:
    print(i)