class Book:
    def __init__(self, title, author, isbn):
        self._title = title
        self._author = author
        self._isbn = isbn

    def get_title(self):
        return self._title

    def set_title(self, title):
        self._title = title

    def get_author(self):
        return self._author

    def set_author(self, author):
        self._author = author

    def get_isbn(self):
        return self._isbn

    def set_isbn(self, isbn):
        self._isbn = isbn

    def __str__(self):
        return f"Book(title='{self._title}', author='{self._author}', isbn='{self._isbn}')"


class FictionBook(Book):
    def __init__(self, title, author, isbn, genre):
        super().__init__(title, author, isbn)
        self._genre = genre

    def get_genre(self):
        return self._genre

    def set_genre(self, genre):
        self._genre = genre

    def __str__(self):
        return f"FictionBook(title='{self._title}', author='{self._author}', isbn='{self._isbn}', genre='{self._genre}')"


book = Book("1984", "George Orwell", "1234")
print(book)  

fiction_book = FictionBook("Dune", "Frank Herbert", "0987", "Science Fiction")
print(fiction_book)  
