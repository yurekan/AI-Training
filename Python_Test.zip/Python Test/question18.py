def capitalize_words(input_string):
    # Split the string into words, capitalize each word, and join them back together
    capitalized_string = ' '.join(word.capitalize() for word in input_string.split())
    return capitalized_string


user_input = input("Enter a string: ")
result = capitalize_words(user_input)
print("Capitalized string:", result)
