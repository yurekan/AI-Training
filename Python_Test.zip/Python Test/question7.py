def divide_numbers():
    while True:
        try:
            num1 = float(input("Enter the first number: ")) 
            num2 = float(input("Enter the second number: "))  
            
            result = num1 / num2  
            print(f"The result is: {result}") 
            break 
        
        except ZeroDivisionError:
            print("Error: Division by zero is not allowed.")  # Handle division by zero
        
        except ValueError:
            print("Error: Please enter valid numbers.")  # Handle invalid input

divide_numbers() 
