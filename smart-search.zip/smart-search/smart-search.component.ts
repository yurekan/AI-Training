import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as Papa from 'papaparse';
import { CohereClientV2 } from 'cohere-ai';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

interface Product {
  name: string;
  model: string;
  combo: string;
  size: string;
  price: string;
  description: string;
  specification: string;
  features: string;
  sub_category: string;
  category: string;
  parent_category: string;
}

@Component({
  selector: 'app-smart-search',
  standalone: true,
  templateUrl: './smart-search.component.html',
  styleUrls: ['./smart-search.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class SmartSearchComponent implements OnInit {
  userDescription: string = '';
  recommendations: any[] = [];
  loading: boolean = false;
  errorMessage: string = '';
  products: Product[] = [];
  private co!: CohereClientV2;
  private cohereApiKey = 'lFPJJUNoM3hmzNVjvvMa1ZkPqzqzBTCccNBX7GU4';
  private csvFilePath = 'assets/FinalSony_TV_Audio_Cameras_data.csv';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.initializeCohere();
    this.loadProducts();
  }

  private initializeCohere(): void {
    console.time('Initialize Cohere');
    this.co = new CohereClientV2({
      token: this.cohereApiKey,
    });
    console.timeEnd('Initialize Cohere');
  }

  private loadProducts(): void {
    console.time('Load Products');
    this.http.get(this.csvFilePath, { responseType: 'text' }).subscribe({
      next: (data) => {
        console.time('Parse CSV');
        Papa.parse(data, {
          header: true,
          skipEmptyLines: true,
          complete: (result) => {
            console.timeEnd('Parse CSV');
            if (result.errors.length > 0) {
              console.error('CSV Parsing Errors:', result.errors);
              this.errorMessage = 'Failed to parse product data.';
            } else {
              this.products = result.data as Product[];
              console.log('Products loaded successfully:', this.products);
            }
          },
          error: (err: any) => {
            console.error('Parsing Error:', err);
            this.errorMessage = 'An error occurred during parsing.';
          },
        });
      },
      error: (error) => {
        console.error('HTTP Error:', error);
        this.errorMessage = 'Failed to load product data. Ensure the file is accessible.';
      },
    });
    console.timeEnd('Load Products');
  }

  async getRecommendations(): Promise<void> {
    if (!this.co) {
      throw new Error('Cohere client not initialized.');
    }
    this.loading = true;
    this.errorMessage = '';
    this.recommendations = [];

    try {
      console.time('Total Recommendation Time');

      // Step 1: Format product details
      console.time('Format Product Details');
      const productDetails = this.formatProductDetails(this.products);
      console.timeEnd('Format Product Details');

      // Step 2: Generate prompt
      console.time('Generate Prompt');

      // const prompt = `
      //   Based on the user's description: "${this.userDescription}",
      //   suggest the best suitable products from the list below and explain why they are suitable.
      //   For each suggestion, provide the name, model, price, and a brief reason for suitability.

      //   ${productDetails}

      //   Provide the top 3 recommendations in the following format below and do not include additional text:
      //     Name: ...
      //     Model: ...
      //     Price: ...
      //     Suitability: (Explain briefly why this product meets the user's needs)
      // `;
      
      const prompt = `
              You are a highly accurate assistant. Based on the user's description: "${this.userDescription}",
              suggest the best suitable products from the list below and explain why they are suitable.
      
              ${productDetails}
      
              For each suggestion, provide the following details:
              - Name
              - Model
              - Price
              - A brief reason for suitability
      
              Your response must strictly follow the JSON format shown below. Do not include additional text, explanations, or any alternative formatting like tables or plain text.
      
              Example:
              [
                {
                  "Name": "Product 1",
                  "Model": "Model 1",
                  "Price": "Price 1",
                  "Suitability": "Reason for suitability 1"
                },
                {
                  "Name": "Product 2",
                  "Model": "Model 2",
                  "Price": "Price 2",
                  "Suitability": "Reason for suitability 2"
                },
                {
                  "Name": "Product 3",
                  "Model": "Model 3",
                  "Price": "Price 3",
                  "Suitability": "Reason for suitability 3"
                }
              ]
      
              Ensure your output strictly matches the format above. If the format is not strictly followed, the response will be considered invalid.
                    
              `;

      console.timeEnd('Generate Prompt');

      // Step 3: Call Cohere API
      console.time('Cohere API Call');
      const response = await this.getCohereChatResponse(prompt);
      console.timeEnd('Cohere API Call');

      console.log('response: ', response);

      // Step 4: Process API response
      console.time('Process API Response');
      this.recommendations = response.split('\n').map((item) => item.trim());
      console.timeEnd('Process API Response');

      console.timeEnd('Total Recommendation Time');
    } catch (error) {
      this.errorMessage = 'Failed to fetch recommendations.';
      console.error(error);
    } finally {
      this.loading = false;
    }
  }

  private async getCohereChatResponse(prompt: string): Promise<string> {
    console.time('Cohere Chat Response');
    const response = await this.co.chat({
      model: 'command-r-plus',
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
    });
    console.timeEnd('Cohere Chat Response');

    if (response && response.message && response.message.content) {
      return response.message.content.map((item) => item.text.trim()).join('\n');
    } else {
      throw new Error('No content generated.');
    }
  }

  private formatProductDetails(products: Product[]): string {
    console.time('Product Details Formatting');
    const formattedDetails = products
      .map((product) =>
        Object.entries(product)
          .map(([key, value]) => `${this.capitalize(key)}: ${value}`)
          .join(', ')
      )
      .join('\n');
    console.timeEnd('Product Details Formatting');
    return formattedDetails;
  }

  private capitalize(text: string): string {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }
}